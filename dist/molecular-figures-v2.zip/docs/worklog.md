# Work log, figures-v2

## 2026-10-03, end of the calibration session
Done: fresh tree; figures/shared/primitives.tex (crescent atoms, rods, solid and ghost molecule modes,
leader labels, zoom bubble, plates, level rules, thick-tube pic); studies/primitives-proof.tex.
Verdict on the proof sheet (build/studies/primitives-proof.png): the molecule primitive passes
(solid methylamine, ghost copy, water, K and Rb discs). The thick-tube pic FAILS and must be rebuilt
before it is used: the top annulus is drawn complete instead of leaving the wedge sector open; the
cut faces are drawn in the wrong order and read as a flat tinted rectangle; the ghost band inside the
wedge is missing; version points fall inside the opening. The working reference for the correct
construction and order is studies/tube-study.tex and studies/harter-idiom.tex (inner wall, outer wall
pieces, ghost band with the tu path, cut faces hatched, top face as annulus minus the sector, then
points and leaders). Rebuild the pic from that order, prove it on the sheet, then proceed to the
prototypes (figures 6, 5, 10).
Nothing in this tree is yet at the standard of section 8. Keep iterating.

## 2026-10-04, continuation after the author's review round
- Rod junctions computed (bonds leave the far sphere on the projected junction curve); digits inside hydrogens.
- Figures 1, 5, 6, 7, 9, 10 reworked after feedback; figures 2, 3, 4, 8, 11, 12 and the guide drawn from
  alternative studies (studies/alternatives, docs/illustration-notes.md); twelve-approach exploration of the
  solid and eight-approach exploration of the molecule shading.
- Reference material kept in the repository (manuscript export, handoff package, plate scans).
- build.py: proof sheet, squint sheet, grayscale proof, deliverable PDFs, collision report; scaffold rebuilt.
- Open for the author: section order of the export against the specification (docs/author-decisions.md).
